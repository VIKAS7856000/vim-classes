VIM CLASSES BELBATHAN WEBSITE
=============================

Files:
- index.html: responsive coaching website (mobile + desktop)

How to preview:
1. Download and open index.html in a browser.

How to publish for free:
1. Create/sign in to a GitHub account.
2. Create a new public repository named vim-classes-belbathan (or any available name).
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch, choose main and /(root), then Save.
6. Wait for GitHub Pages to publish the site. The live URL will appear in Settings > Pages.

Important:
- The website currently uses the provided coaching name, contact number, email, and location details.
- Notes/PDFs/results are placeholders until you provide the real files/links.
- This is a static information website. Student accounts, secure admin panel, database, and online payments are not included.
